﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Example_5_14____The_for_Loop
{
    class Program
    {

        public static void Main()
        {
            for (int counter = 0; counter < 10; counter++)
            {
                Console.WriteLine("counter: {0} ", counter);
            }
        }
    }
}
