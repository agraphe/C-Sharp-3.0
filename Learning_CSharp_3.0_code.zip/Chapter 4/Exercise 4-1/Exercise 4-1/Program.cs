﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise_4_1
{
    class Program
    {
        static void Main()
        {
            int x = 25;
            int y = 5;
            Console.WriteLine("sum: {0}, difference: {1}, product: {2}, quotient: {3}, modulus: {4}.", x + y, x - y, x * y, x / y, x % y);
        }
    }
}
