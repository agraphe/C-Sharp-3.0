﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise_3_3
{
    class Exercise
    {
        static void Main()
        {
            const double Pi = 3.14159;
            Console.WriteLine("The value of pi is: {0}", Pi);
            Pi = 3.1;
            Console.WriteLine("The value of pi is: {0}", Pi);
        }
    }
}
