﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise_1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What a great book!");
        }
    }
}
