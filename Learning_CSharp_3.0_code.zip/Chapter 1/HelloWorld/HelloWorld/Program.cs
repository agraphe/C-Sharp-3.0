﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            // every console app starts with Main
            System.Console.WriteLine("Hello World!");
        }
    }
}
